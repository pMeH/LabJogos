class Personagem(object):

    #Personagem
    TRUMP = 1
    MEXICANO = 2
    TERRORISTA = 3
    PUTIN = 4

    #Pronto?
    NAO = 0
    SIM = 1

    #Arena
    CASA_BRANCA = 1
    NEVE = 2
    MURO = 3
    ATLANTIDA = 4
    LUA = 5
    ALEATORIO = 6

    def __init__(self,state = TRUMP, pronto = NAO, arena = CASA_BRANCA):
        self.state = state
        self.pronto = pronto
        self.arena = arena

    def setState(self, state):
        self.state = state

    def getState(self):
        return self.state

    def setPronto(self, pronto):
        self.pronto = pronto

    def getPronto(self):
        return self.pronto

    def setArena(self, arena):
        self.arena = arena

    def getArena(self):
        return self.arena