from PPlay.gameimage import *
from PPlay.window import *
from PPlay.sprite import *
from PPlay.sound import *
from GameState import*
from Frame import *
from Animacao import *

#Geral
janela = Window(700, 400)
janela.set_title("Make America a Game Again")
teclado = Window.get_keyboard()
status=GameState(GameState.START)

# Botao de Start
fundo_start = GameImage("Again.png")
button_start = Sprite("Start.png", 2)
button_start.set_total_duration(1000)
button_start.move_x(108)
button_start.move_y(324)
button_start.set_sequence(0, 2,True)
som = Sound("Trump_total.ogg")
som.load("Trump_total.ogg")
som.set_volume(100)
som.play()

# Tela inicial
status_escolhas = Frame(Frame.JOGAR)
fundo_escolhas = GameImage("Flag.jpg")
frame_escolhas = GameImage("Frame.png")

# Controles
fundo_controles = GameImage("Controles.png")

# Jogo
fundo_jogo = GameImage("background.jpg")
    #Primeiro personagem
animacao = Sprite("full_terrorista_total.png",30)
p1_posicao_x = 8
p1_posicao_y = 250
p1_subindo = 0
animacao.move_x(p1_posicao_x)
animacao.move_y(p1_posicao_y)
animacao.set_sequence(0, 3, True)
status_animacao = Animacao(Animacao.PARADO, Animacao.INICIAL, Animacao.INICIAL, Animacao.CHAO)
animacao.set_total_duration(4000)
    #Segundo personagem
animacao2 = Sprite("full_trump_total.png",30)
p2_posicao_x = 540
p2_posicao_y = 250
p2_subindo = 0
animacao2.move_x(p2_posicao_x)
animacao2.move_y(p2_posicao_y)
animacao2.set_sequence(15, 18, True)
status_animacao2 = Animacao(Animacao.PARADO, Animacao.INICIAL, Animacao.INICIAL, Animacao.CHAO)
animacao2.set_total_duration(4000)

u = 0
i = 15

dt = janela.delta_time()

def start(teclado):
    fundo_start.draw()
    button_start.draw()
    button_start.update()
    if(teclado.key_pressed("SPACE")):
            status.setState(GameState.ESCOLHAS)

def escolhas(teclado):
    fundo_escolhas.draw()
    frame_escolhas.draw()

    if ((teclado.key_pressed("w")) or (teclado.key_pressed("up"))) and status_escolhas.getState()== 1:
        status_escolhas.setState(Frame.SAIR)
        janela.delay(50)
    elif ((teclado.key_pressed("s")) or (teclado.key_pressed("down"))) and status_escolhas.getState()== 1:
        status_escolhas.setState(Frame.CONTROLES)
        janela.delay(150)
    elif ((teclado.key_pressed("w")) or (teclado.key_pressed("up"))) and status_escolhas.getState()== 2:
        status_escolhas.setState(Frame.JOGAR)
        janela.delay(150)
    elif ((teclado.key_pressed("s")) or (teclado.key_pressed("down"))) and status_escolhas.getState()== 2:
        status_escolhas.setState(Frame.SAIR)
        janela.delay(150)
    elif ((teclado.key_pressed("w")) or (teclado.key_pressed("up"))) and status_escolhas.getState()== 3:
        status_escolhas.setState(Frame.CONTROLES)
        janela.delay(150)
    elif ((teclado.key_pressed("s")) or (teclado.key_pressed("down"))) and status_escolhas.getState()== 3:
        status_escolhas.setState(Frame.JOGAR)
        janela.delay(150)

    if status_escolhas.getState() == 1:
        frame_escolhas.set_position(256,125)
        if teclado.key_pressed("ENTER"):
            status.setState(GameState.JOGO)
    elif status_escolhas.getState() == 2:
        frame_escolhas.set_position(256,201)
        if teclado.key_pressed("ENTER"):
            status.setState(GameState.CONTROLES)
    elif status_escolhas.getState() == 3:
        frame_escolhas.set_position(256,282)
        if teclado.key_pressed("ENTER"):
            janela.close()

def personagem(teclado):
    print("AINDA NAO IMPLEMENTADO")

def controles(teclado):
    fundo_controles.draw()
    if teclado.key_pressed("ENTER"):
        status.setState(GameState.ESCOLHAS)

while True:
    if status.getState() == GameState.START:
        start(teclado)
    elif status.getState() == GameState.ESCOLHAS:
        escolhas(teclado)
    elif status.getState() == GameState.CONTROLES:
        controles(teclado)
    elif status.getState() == GameState.PERSONAGEM:
        personagem(teclado)
    elif status.getState() == GameState.JOGO:



        # Variaveis criadas com o proposito de que os sprites serao trocados apenas quando o proximo
        # for diferente do anterior para que nao fique voltando para o comeco o tempo t_odo.
        p1_modificacao = status_animacao.getState()
        p2_modificacao = status_animacao2.getState()

        ######## Mudanca de Sprite (direita pra esquerda) #########
        if p2_posicao_x > p1_posicao_x:
            u = 0
            i = 15
        if p2_posicao_x < p1_posicao_x:
            u = 15
            i = 0

        ######### Personagem 1 no chao   #############
        if status_animacao.getState_h() == 1:
            if (teclado.key_pressed("E")):
                status_animacao.setState(Animacao.SOCO)
                status_animacao.setMove_x(dt,Animacao.INICIAL)
            elif (teclado.key_pressed("F")):
                status_animacao.setState(Animacao.CHUTE)
                status_animacao.setMove_x(dt,Animacao.INICIAL)
            elif (teclado.key_pressed("W")):
                status_animacao.setState(Animacao.PULAR)
                status_animacao.setMove_x(dt,Animacao.INICIAL)
                status_animacao.setState_h(Animacao.AR)
                p1_subindo = 0
            elif (teclado.key_pressed("S")):
                status_animacao.setState(Animacao.ABAIXAR)
                status_animacao.setMove_x(dt,Animacao.INICIAL)
            elif(teclado.key_pressed("A")):
                if p1_posicao_x > -30:
                    status_animacao.setState(Animacao.ANDAR)
                    status_animacao.setMove_x(dt,Animacao.ESQUERDA)
                    p1_posicao_x = p1_posicao_x - 400*dt
                else:
                    status_animacao.setMove_x(dt,Animacao.INICIAL)
            elif (teclado.key_pressed("D")):
                if p1_posicao_x < 575:
                    status_animacao.setState(Animacao.ANDAR)
                    status_animacao.setMove_x(dt,Animacao.DIREITA)
                    p1_posicao_x = p1_posicao_x + 400*dt
                else:
                    status_animacao.setMove_x(dt,Animacao.INICIAL)
            else:
                status_animacao.setState(Animacao.PARADO)
                status_animacao.setMove_x(dt,Animacao.INICIAL)

            ######## Persongaem 1 esta no ar ############
        elif status_animacao.getState_h() == 2:
            if(teclado.key_pressed("A")):
                if p1_posicao_x > -30:
                    status_animacao.setMove_x(dt,Animacao.ESQUERDA)
                    p1_posicao_x = p1_posicao_x - 400*dt
                else:
                    status_animacao.setMove_x(dt,Animacao.INICIAL)
            elif (teclado.key_pressed("D")):
                if p1_posicao_x < 575:
                    status_animacao.setMove_x(dt,Animacao.DIREITA)
                    p1_posicao_x = p1_posicao_x + 400*dt
                else:
                    status_animacao.setMove_x(dt,Animacao.INICIAL)
            else:
                status_animacao.setMove_x(dt,Animacao.INICIAL)
            if p1_subindo == 0:
                status_animacao.setMove_y(dt,Animacao.CIMA)
                p1_posicao_y = p1_posicao_y - 1000*dt
                if p1_posicao_y <100:
                    p1_subindo = 1
            elif p1_subindo == 1:
                status_animacao.setMove_y(dt,Animacao.BAIXO)
                p1_posicao_y = p1_posicao_y + 1000*dt
                if p1_posicao_y >= 250:
                    status_animacao.setMove_y(dt,Animacao.INICIAL)
                    status_animacao.setState_h(Animacao.CHAO)
                    p1_posicao_y = p1_posicao_y - 1000*dt

            ########## Sequencias de Sprites do personagem 1 ###########
        if p1_modificacao != status_animacao.getState():
            if status_animacao.getState() == 1:
                animacao.set_sequence(u, u+3, True)
            elif status_animacao.getState() == 2:
                animacao.set_sequence(u+2, u+6, True)
            elif status_animacao.getState() == 3:
                animacao.set_sequence(u+6, u+7, True)
            elif status_animacao.getState() == 4:
                animacao.set_sequence(u+7, u+8, True)
            elif status_animacao.getState() == 5:
                animacao.set_sequence(u+9, u+10, True)
            elif status_animacao.getState() == 6:
                animacao.set_sequence(u+10, u+13, True)

        ######### Personagem 2 esta no chao ###############
        if status_animacao2.getState_h() == 1:
            if (teclado.key_pressed("I")):
                status_animacao2.setState(Animacao.SOCO)
                status_animacao2.setMove_x(dt,Animacao.INICIAL)
            elif (teclado.key_pressed("K")):
                status_animacao2.setState(Animacao.CHUTE)
                status_animacao2.setMove_x(dt,Animacao.INICIAL)
            elif (teclado.key_pressed("UP")):
                status_animacao2.setState(Animacao.PULAR)
                status_animacao2.setMove_x(dt,Animacao.INICIAL)
                status_animacao2.setState_h(Animacao.AR)
                p2_subindo = 0
            elif (teclado.key_pressed("DOWN")):
                status_animacao2.setState(Animacao.ABAIXAR)
                status_animacao2.setMove_x(dt,Animacao.INICIAL)
            elif(teclado.key_pressed("LEFT")):
                if p2_posicao_x > -30:
                    status_animacao2.setState(Animacao.ANDAR)
                    status_animacao2.setMove_x(dt,Animacao.ESQUERDA)
                    p2_posicao_x = p2_posicao_x - 400*dt
                else:
                    status_animacao2.setMove_x(dt,Animacao.INICIAL)
            elif (teclado.key_pressed("RIGHT")):
                if p2_posicao_x < 575:
                    status_animacao2.setState(Animacao.ANDAR)
                    status_animacao2.setMove_x(dt,Animacao.DIREITA)
                    p2_posicao_x = p2_posicao_x + 400*dt
                else:
                    status_animacao2.setMove_x(dt,Animacao.INICIAL)
            else:
                status_animacao2.setState(Animacao.PARADO)
                status_animacao2.setMove_x(dt,Animacao.INICIAL)

            ########## Persongaem 2 esta no ar ###############
        elif status_animacao2.getState_h() == 2:
            if(teclado.key_pressed("LEFT")):
                if p2_posicao_x > -30:
                    status_animacao2.setMove_x(dt,Animacao.ESQUERDA)
                    p2_posicao_x = p2_posicao_x - 400*dt
                else:
                    status_animacao2.setMove_x(dt,Animacao.INICIAL)
            elif (teclado.key_pressed("RIGHT")):
                if p2_posicao_x < 575:
                    status_animacao2.setMove_x(dt,Animacao.DIREITA)
                    p2_posicao_x = p2_posicao_x + 400*dt
                else:
                    status_animacao2.setMove_x(dt,Animacao.INICIAL)
            else:
                status_animacao2.setMove_x(dt,Animacao.INICIAL)
            if p2_subindo == 0:
                status_animacao2.setMove_y(dt,Animacao.CIMA)
                p2_posicao_y = p2_posicao_y - 1000*dt
                if p2_posicao_y <100:
                    p2_subindo = 1
            elif p2_subindo == 1:
                status_animacao2.setMove_y(dt,Animacao.BAIXO)
                p2_posicao_y = p2_posicao_y + 1000*dt
                if p2_posicao_y > 249.6:
                    status_animacao2.setMove_y(dt,Animacao.INICIAL)
                    status_animacao2.setState_h(Animacao.CHAO)
                    p2_posicao_y = p2_posicao_y - 1000*dt

        ########## Sequencias de Sprites do personagem 2 ###########
        if p2_modificacao != status_animacao2.getState():
            if status_animacao2.getState() == 1:
                animacao2.set_sequence(i+0, i+3, True)
            elif status_animacao2.getState() == 2:
                animacao2.set_sequence(i+2, i+6, True)
            elif status_animacao2.getState() == 3:
                animacao2.set_sequence(i+6, i+7, True)
            elif status_animacao2.getState() == 4:
                animacao2.set_sequence(i+7, i+8, True)
            elif status_animacao2.getState() == 5:
                animacao2.set_sequence(i+9, i+10, True)
            elif status_animacao2.getState() == 6:
                animacao2.set_sequence(i+10, i+13, True)

        dt = janela.delta_time()
        fundo_jogo.draw()
        animacao.move_x(status_animacao.getMove_x())
        animacao.move_y(status_animacao.getMove_y())
        animacao.draw()
        animacao.update()
        animacao2.move_x(status_animacao2.getMove_x())
        animacao2.move_y(status_animacao2.getMove_y())
        animacao2.draw()
        animacao2.update()
        print(p1_posicao_x)
        print(p1_posicao_y)
    janela.update()