from PPlay.gameimage import *
from PPlay.window import *
from PPlay.sprite import *
from PPlay.sound import *
from GameState import*
from Frame import *
from Selecao_Personagem import *
from Animacao import *
from Round import *

#Geral
janela = Window(700, 400)
janela.set_title("Make America a Game Again")
teclado = Window.get_keyboard()
status=GameState(GameState.START)

# Botao de Start
fundo_start = GameImage("Again.png")
button_start = Sprite("Start.png", 2)
button_start.set_total_duration(1000)
button_start.move_x(108)
button_start.move_y(324)
button_start.set_sequence(0, 2,True)
#som = Sound("Trump_total.ogg")
#som.load("Trump_total.ogg")
#som.set_volume(100)
#som.play()

# Tela inicial
status_escolhas = Frame(Frame.JOGAR)
fundo_escolhas = GameImage("Flag.jpg")
frame_escolhas = GameImage("Frame.png")
frame_escolhas.set_position(256,125)

# Selecao de persongens
status_personagem_p1 = Personagem(Personagem.TRUMP,Personagem.NAO)
status_personagem_p2 = Personagem(Personagem.PUTIN,Personagem.NAO)
fundo_personagem = GameImage("selecao_personagem_fundo.png")
p1_frame_personagem = GameImage("selecao_frame_p1.png")
p2_frame_personagem = GameImage("selecao_frame_p2.png")
p3_frame_personagem = GameImage("selecao_frame_ambos.png")
 # Sprites p1 do selecao de personagens
p1_animacao_personagem = Sprite("personagens_direita.png",12)
p1_animacao_personagem.move_x(60)
p1_animacao_personagem.move_y(110)
p1_animacao_personagem.set_sequence(0, 3, True)
p1_animacao_personagem.set_total_duration(1600)
 # Sprites p2 da selecao de personagens
p2_animacao_personagem = Sprite("personagens_esquerda.png",12)
p2_animacao_personagem.move_x(480)
p2_animacao_personagem.move_y(105)
p2_animacao_personagem.set_sequence(9, 12, True)
p2_animacao_personagem.set_total_duration(1600)

# Controles
fundo_controles = GameImage("Controles.png")

# Jogo
fundo_jogo = GameImage("background 2.jpg")
status_round = Round(Round.ROUND_1,Round.P1_VITORIA_0,Round.P2_VITORIA_0)
    # Primeiro personagem
p1_posicao_x = 8
p1_posicao_y = 250
texto_personagem_p1 = "TRUMP"
status_animacao = Animacao(Animacao.PARADO, Animacao.INICIAL, Animacao.INICIAL, Animacao.CHAO, Animacao.NAO)
HP1 = 100 # Variavel que controla a vida
HP_p1 = Sprite("HP_p1.png",21)
HP_p1.set_total_duration(4000)
HP_p1.set_position(20,30)
especial_1 = 0
especial_p1 = Sprite("especial_p1.png",11)
especial_p1.set_total_duration(4000)
especial_p1.set_position(20,50)
    # Segundo personagem
p2_posicao_x = 540
p2_posicao_y = 250
texto_personagem_p2 = "TRUMP"
status_animacao2 = Animacao(Animacao.PARADO, Animacao.INICIAL, Animacao.INICIAL, Animacao.CHAO, Animacao.NAO)
HP2 = 100 # Variavel que controla a vida
HP_p2 = Sprite("HP_p2.png",21)
HP_p2.set_total_duration(4000)
HP_p2.set_position(480,30)
especial_2 = 0
especial_p2 = Sprite("especial_p2.png",11)
especial_p2.set_total_duration(4000)
especial_p2.set_position(580,50)
    # Geral
round_atual = status_round.getRound()
texto_round = "ROUND 1"
duracao_ataque_p1 = 0
duracao_ataque_p2 = 0
delay1 = 0
delay2 = 0
delay1_mov = 0
delay2_mov = 0
dt = janela.delta_time()
tempo = 0
    # Especial
especial_trump_d = GameImage("especial_trump_d.png")
especial_trump_e = GameImage("especial_trump_e.png")
especial_terrorista = GameImage("especial_terrorista.png")
velocidade_especial_p1 = 0
velocidade_especial_p2 = 0

def start(teclado):
    fundo_start.draw()
    button_start.draw()
    button_start.update()
    if(teclado.key_pressed("SPACE")):
            status.setState(GameState.ESCOLHAS)

def escolhas(teclado):
    fundo_escolhas.draw()
    frame_escolhas.draw()

    if ((teclado.key_pressed("w")) or (teclado.key_pressed("up"))) and status_escolhas.getState()== 1:
        status_escolhas.setState(Frame.SAIR)
        janela.delay(150)
    elif ((teclado.key_pressed("s")) or (teclado.key_pressed("down"))) and status_escolhas.getState()== 1:
        status_escolhas.setState(Frame.CONTROLES)
        janela.delay(150)
    elif ((teclado.key_pressed("w")) or (teclado.key_pressed("up"))) and status_escolhas.getState()== 2:
        status_escolhas.setState(Frame.JOGAR)
        janela.delay(150)
    elif ((teclado.key_pressed("s")) or (teclado.key_pressed("down"))) and status_escolhas.getState()== 2:
        status_escolhas.setState(Frame.SAIR)
        janela.delay(150)
    elif ((teclado.key_pressed("w")) or (teclado.key_pressed("up"))) and status_escolhas.getState()== 3:
        status_escolhas.setState(Frame.CONTROLES)
        janela.delay(150)
    elif ((teclado.key_pressed("s")) or (teclado.key_pressed("down"))) and status_escolhas.getState()== 3:
        status_escolhas.setState(Frame.JOGAR)
        janela.delay(150)

    if status_escolhas.getState() == 1:
        frame_escolhas.set_position(256,125)
        if teclado.key_pressed("ENTER"):
            status.setState(GameState.PERSONAGEM)
            janela.delay(150)
    elif status_escolhas.getState() == 2:
        frame_escolhas.set_position(256,201)
        if teclado.key_pressed("ENTER"):
            status.setState(GameState.CONTROLES)
    elif status_escolhas.getState() == 3:
        frame_escolhas.set_position(256,282)
        if teclado.key_pressed("ENTER"):
            janela.close()

def personagem(teclado):

    status_personagem_iguais = 0
    modificacao_personagem_p1 = status_personagem_p1.getState()
    modificacao_personagem_p2 = status_personagem_p2.getState()

    if status_personagem_p1.getPronto() == 0:
        ########## Frame para o player 1 #############
        if(teclado.key_pressed("d")) and status_personagem_p1.getState()== 1:
            status_personagem_p1.setState(Personagem.MEXICANO)
            janela.delay(190)
        elif(teclado.key_pressed("d")) and status_personagem_p1.getState()== 2:
            status_personagem_p1.setState(Personagem.TERRORISTA)
            janela.delay(190)
        elif(teclado.key_pressed("d")) and status_personagem_p1.getState()== 3:
            status_personagem_p1.setState(Personagem.PUTIN)
            janela.delay(190)
        elif(teclado.key_pressed("d")) and status_personagem_p1.getState()== 4:
            status_personagem_p1.setState(Personagem.TRUMP)
            janela.delay(190)
        elif(teclado.key_pressed("a")) and status_personagem_p1.getState()== 1:
            status_personagem_p1.setState(Personagem.PUTIN)
            janela.delay(190)
        elif(teclado.key_pressed("a")) and status_personagem_p1.getState()== 2:
            status_personagem_p1.setState(Personagem.TRUMP)
            janela.delay(190)
        elif(teclado.key_pressed("a")) and status_personagem_p1.getState()== 3:
            status_personagem_p1.setState(Personagem.MEXICANO)
            janela.delay(190)
        elif(teclado.key_pressed("a")) and status_personagem_p1.getState()== 4:
            status_personagem_p1.setState(Personagem.TERRORISTA)
            janela.delay(190)

    if status_personagem_p2.getPronto() == 0:
        ########## Frame para o player 2 ##############
        if(teclado.key_pressed("right")) and status_personagem_p2.getState()== 1:
            status_personagem_p2.setState(Personagem.MEXICANO)
            janela.delay(190)
        elif(teclado.key_pressed("right")) and status_personagem_p2.getState()== 2:
            status_personagem_p2.setState(Personagem.TERRORISTA)
            janela.delay(190)
        elif(teclado.key_pressed("right")) and status_personagem_p2.getState()== 3:
            status_personagem_p2.setState(Personagem.PUTIN)
            janela.delay(190)
        elif(teclado.key_pressed("right")) and status_personagem_p2.getState()== 4:
            status_personagem_p2.setState(Personagem.TRUMP)
            janela.delay(190)
        elif(teclado.key_pressed("left")) and status_personagem_p2.getState()== 1:
            status_personagem_p2.setState(Personagem.PUTIN)
            janela.delay(190)
        elif(teclado.key_pressed("left")) and status_personagem_p2.getState()== 2:
            status_personagem_p2.setState(Personagem.TRUMP)
            janela.delay(190)
        elif(teclado.key_pressed("left")) and status_personagem_p2.getState()== 3:
            status_personagem_p2.setState(Personagem.MEXICANO)
            janela.delay(190)
        elif(teclado.key_pressed("left")) and status_personagem_p2.getState()== 4:
            status_personagem_p2.setState(Personagem.TERRORISTA)
            janela.delay(190)

    ################## Para o plyer 1 #####################
    if status_personagem_p1.getState() == 1:
        if status_personagem_p1.getState() == status_personagem_p2.getState():
            p3_frame_personagem.set_position(91,301)
            status_personagem_iguais = 1
        p1_frame_personagem.set_position(91,301)
        if teclado.key_pressed("e"):
            status_personagem_p1.setPronto(Personagem.SIM)
    elif status_personagem_p1.getState() == 2:
        if status_personagem_p1.getState() == status_personagem_p2.getState():
            p3_frame_personagem.set_position(217,301)
            status_personagem_iguais = 1
        p1_frame_personagem.set_position(217,301)
        if teclado.key_pressed("e"):
            status_personagem_p1.setPronto(Personagem.SIM)
    elif status_personagem_p1.getState() == 3:
        if status_personagem_p1.getState() == status_personagem_p2.getState():
            p3_frame_personagem.set_position(346,301)
            status_personagem_iguais = 1
        p1_frame_personagem.set_position(346,301)
        if teclado.key_pressed("e"):
            status_personagem_p1.setPronto(Personagem.SIM)
    elif status_personagem_p1.getState() == 4:
        if status_personagem_p1.getState() == status_personagem_p2.getState():
            p3_frame_personagem.set_position(475,301)
            status_personagem_iguais = 1
        p1_frame_personagem.set_position(475,301)
        if teclado.key_pressed("e"):
            status_personagem_p1.setPronto(Personagem.SIM)

    ################## Para o plyer 2 #####################
    if status_personagem_p2.getState() == 1:
        p2_frame_personagem.set_position(91,301)
        if teclado.key_pressed("i"):
            status_personagem_p2.setPronto(Personagem.SIM)
    elif status_personagem_p2.getState() == 2:
        p2_frame_personagem.set_position(217,301)
        if teclado.key_pressed("i"):
            status_personagem_p2.setPronto(Personagem.SIM)
    elif status_personagem_p2.getState() == 3:
        p2_frame_personagem.set_position(346,301)
        if teclado.key_pressed("i"):
            status_personagem_p2.setPronto(Personagem.SIM)
    elif status_personagem_p2.getState() == 4:
        p2_frame_personagem.set_position(475,301)
        if teclado.key_pressed("i"):
            status_personagem_p2.setPronto(Personagem.SIM)

    ################ Sprites p1 #######################

    if modificacao_personagem_p1 != status_personagem_p1.getState():
        if status_personagem_p1.getState() == 1:
            p1_animacao_personagem.set_sequence(0, 3, True)
        elif status_personagem_p1.getState() == 2:
            p1_animacao_personagem.set_sequence(3, 6, True)
        elif status_personagem_p1.getState() == 3:
            p1_animacao_personagem.set_sequence(6, 9, True)
        elif status_personagem_p1.getState() == 4:
            p1_animacao_personagem.set_sequence(9, 12, True)

    ################ Sprites p2 ############################

    if modificacao_personagem_p2 != status_personagem_p2.getState():
        if status_personagem_p2.getState() == 1:
            p2_animacao_personagem.set_sequence(0, 3, True)
        elif status_personagem_p2.getState() == 2:
            p2_animacao_personagem.set_sequence(3, 6, True)
        elif status_personagem_p2.getState() == 3:
            p2_animacao_personagem.set_sequence(6, 9, True)
        elif status_personagem_p2.getState() == 4:
            p2_animacao_personagem.set_sequence(9, 12, True)

    ############ Lugar que o frame eh enviado quando nao foi utilizado ################
    if status_personagem_iguais == 0:
        p3_frame_personagem.set_position(-100,-100)

    fundo_personagem.draw()

    p1_frame_personagem.draw()
    p2_frame_personagem.draw()
    p3_frame_personagem.draw()

    p1_animacao_personagem.draw()
    p1_animacao_personagem.update()
    p2_animacao_personagem.draw()
    p2_animacao_personagem.update()

    if status_personagem_p1.getPronto() == 1:
        if teclado.key_pressed("f"):
            status_personagem_p1.setPronto(Personagem.NAO)
            janela.delay(150)
        else:
            janela.draw_text("Selecionado", 75, 285, size=20, color=(255,255,0), font_name="Franklin Gothic Demi Cond", bold=True, italic=True)
    if status_personagem_p2.getPronto() == 1:
        if teclado.key_pressed("k"):
            status_personagem_p1.setPronto(Personagem.NAO)
            janela.delay(150)
        else:
            janela.draw_text("Selecionado", 505, 285, size=20, color=(255,255,0), font_name="Franklin Gothic Demi Cond", bold=True, italic=True)

    if status_personagem_p1.getPronto() == 1 and status_personagem_p2.getPronto() == 1:
        status.setState(GameState.JOGO)

def controles(teclado):
    fundo_controles.draw()
    if teclado.key_pressed("ENTER"):
        status.setState(GameState.ESCOLHAS)

def HP_controle(HP1,HP_p1):
    if HP1 == 100:
        HP_p1.set_sequence(0, 1, True)
    elif 95 == HP1:
        HP_p1.set_sequence(1, 2, True)
    elif 90 == HP1:
        HP_p1.set_sequence(2, 3, True)
    elif 85 == HP1:
        HP_p1.set_sequence(3, 4, True)
    elif 80 == HP1:
        HP_p1.set_sequence(4, 5, True)
    elif 75 == HP1:
        HP_p1.set_sequence(5, 6, True)
    elif 70 == HP1:
        HP_p1.set_sequence(6, 7, True)
    elif 65 == HP1:
        HP_p1.set_sequence(7, 8, True)
    elif 60 == HP1:
        HP_p1.set_sequence(8, 9, True)
    elif 55 == HP1:
        HP_p1.set_sequence(9, 10, True)
    elif 50 == HP1:
        HP_p1.set_sequence(10, 11, True)
    elif 45 == HP1:
        HP_p1.set_sequence(11, 12, True)
    elif 40 == HP1:
        HP_p1.set_sequence(12, 13, True)
    elif 35 == HP1:
        HP_p1.set_sequence(13, 14, True)
    elif 30 == HP1:
        HP_p1.set_sequence(14, 15, True)
    elif 25 == HP1:
        HP_p1.set_sequence(15, 16, True)
    elif 20 == HP1:
        HP_p1.set_sequence(16, 17, True)
    elif 15 == HP1:
        HP_p1.set_sequence(17, 18, True)
    elif 10 == HP1:
        HP_p1.set_sequence(19, 20, True)
    elif 5 == HP1:
        HP_p1.set_sequence(20, 21, True)

def especial_controle(especial_1,especial_p1):
    if especial_1 == 0:
        especial_p1.set_sequence(10, 11, True)
    elif especial_1 == 10:
        especial_p1.set_sequence(9 , 10, True)
    elif especial_1 == 20:
        especial_p1.set_sequence(8 , 9, True)
    elif especial_1 == 30:
        especial_p1.set_sequence(7 , 8, True)
    elif especial_1 == 40:
        especial_p1.set_sequence(6 , 7, True)
    elif especial_1 == 50:
        especial_p1.set_sequence(5 , 6, True)
    elif especial_1 == 60:
        especial_p1.set_sequence(4 , 5, True)
    elif especial_1 == 70:
        especial_p1.set_sequence(3 , 4, True)
    elif especial_1 == 80:
        especial_p1.set_sequence(2 , 3, True)
    elif especial_1 == 90:
        especial_p1.set_sequence(1 , 2, True)
    elif especial_1 == 100:
        especial_p1.set_sequence(0 , 1, True)

def especial_usar(a,u_i,v):
    if a == 1:     # Trump
        if u_i == 0:
            especial_trump_e.set_position(0+v,250)
            especial_trump_e.draw()
        elif u_i == 15:
            especial_trump_d.set_position(575-v,250)
            especial_trump_d.draw()
    if a == 2:   # Mexicano
        if u_i == 0:
            especial_trump_e.set_position(0+v,250)
            especial_trump_e.draw()
        elif u_i == 15:
            especial_trump_d.set_position(575-v,250)
            especial_trump_d.draw()
    if a == 3:    # Terrorista
        if u_i == 0:
            especial_terrorista.set_position(0+v,250)
            especial_terrorista.draw()
        elif u_i == 15:
            especial_terrorista.set_position(320-v,250)
            especial_terrorista.draw()
    if a == 4:    # Putin
        if u_i == 0:
            especial_trump_e.set_position(0+v,250)
            especial_trump_e.draw()
        elif u_i == 15:
            especial_trump_d.set_position(575-v,250)
            especial_trump_d.draw()
    v += 10
    return v

while True:
    if status.getState() == GameState.START:
        start(teclado)
    elif status.getState() == GameState.ESCOLHAS:
        escolhas(teclado)
    elif status.getState() == GameState.PERSONAGEM:
        personagem(teclado)
    elif status.getState() == GameState.CONTROLES:
        controles(teclado)
    elif status.getState() == GameState.JOGO:

        ######## Seleciona o Personagem escolhido ##########
        if status_personagem_p1.getPronto() == 1 and status_personagem_p2.getPronto() == 1:
            if status_personagem_p1.getState() == 1:
                animacao = Sprite("Trump.png",30)
                texto_personagem_p1 = "TRUMP"
            elif status_personagem_p1.getState() == 2:
                animacao = Sprite("Mexicano.png",30)
                texto_personagem_p1 = "MEXICANO"
            elif status_personagem_p1.getState() == 3:
                animacao = Sprite("Terrorista.png",30)
                texto_personagem_p1 = "TERRORISTA"
            elif status_personagem_p1.getState() == 4:
                animacao = Sprite("Terrorista.png",30)
                texto_personagem_p1 = "PUTIN"

            if status_personagem_p2.getState() == 1:
                animacao2 = Sprite("Trump.png",30)
                texto_personagem_p2 = "TRUMP"
            elif status_personagem_p2.getState() == 2:
                animacao2 = Sprite("Mexicano.png",30)
                texto_personagem_p2 = "MEXICANO"
            elif status_personagem_p2.getState() == 3:
                animacao2 = Sprite("Terrorista.png",30)
                texto_personagem_p2 = "TERRORISTA"
            elif status_personagem_p2.getState() == 4:
                animacao2 = Sprite("Terrorista.png",30)
                texto_personagem_p2 = "PUTIN"

            animacao.move_x(8)
            animacao.move_y(250)
            animacao.set_sequence(0, 3, True)
            animacao.set_total_duration(4000)
            p1_posicao_x = 8

            animacao2.move_x(540)
            animacao2.move_y(250)
            animacao2.set_sequence(15, 18, True)
            animacao2.set_total_duration(4000)
            p2_posicao_x = 540

            status_personagem_p1.setPronto(Personagem.NAO)
            status_personagem_p2.setPronto(Personagem.NAO)

            status_round.setRound(Round.ROUND_1)
            status_round.setVitoria_p1(Round.P1_VITORIA_0)
            status_round.setVitoria_p2(Round.P2_VITORIA_0)
            HP1 = 100
            HP2 = 100
            especial_1 = 0
            especial_2 = 0
            round_atual = status_round.getRound()
            texto_round = "ROUND 1"
            velocidade_especial_p1 = 0
            velocidade_especial_p2 = 0

        ######## Detector de rounds ###########
        if round_atual != status_round.getRound():
            HP1 = 100
            HP2 = 100
            animacao.move_x(-(p1_posicao_x - 8))
            p1_posicao_x += (-(p1_posicao_x - 8))
            animacao2.move_x(-(p2_posicao_x - 540))
            p2_posicao_x += (-(p2_posicao_x - 540))
        round_atual = status_round.getRound()

        # Variaveis criadas com o proposito de que os sprites serao trocados apenas quando o proximo
        # for diferente do anterior para que nao fique voltando para o comeco o tempo t_odo.
        p1_modificacao = status_animacao.getState()
        p2_modificacao = status_animacao2.getState()

        ######## Mudanca de Sprite (direita pra esquerda) #########
        if p2_posicao_x >= p1_posicao_x:
            u = 0
            i = 15
        if p2_posicao_x < p1_posicao_x:
            u = 15
            i = 0

        ######### Personagem 1 no chao   #############
        if status_animacao.getState_h() == 1:
            if (teclado.key_pressed("E")) and delay1 == 0:
                status_animacao.setState(Animacao.SOCO)
                status_animacao.setMove_x(dt,Animacao.INICIAL)
                status_animacao.setState_h(Animacao.SOCANDO)
                duracao_ataque_p1 = 0.2
                if status_animacao2.getState_h() == 1 or status_animacao2.getState_h() == 4 or status_animacao2.getState_h() == 5:
                    if 0 < p2_posicao_x - p1_posicao_x < 90:
                        HP2 -= 5
                        if especial_1 < 100:
                            especial_1 += 5
                        animacao2.move_x(100)
                        p2_posicao_x += 100
                    elif -90 < p2_posicao_x - p1_posicao_x < 0:
                        HP2 -= 5
                        if especial_1 < 100:
                            especial_1 += 5
                        animacao2.move_x(-100)
                        p2_posicao_x -= 100
            elif (teclado.key_pressed("F")) and delay1 == 0:
                status_animacao.setState(Animacao.CHUTE)
                status_animacao.setMove_x(dt,Animacao.INICIAL)
                status_animacao.setState_h(Animacao.CHUTANDO)
                duracao_ataque_p1 = 0.4
                if status_animacao2.getState_h() == 1 or status_animacao2.getState_h() == 4 or status_animacao2.getState_h() == 5:
                    if 0 < p2_posicao_x - p1_posicao_x < 90:
                        HP2 -= 10
                        if especial_1 < 100:
                            especial_1 += 5
                        animacao2.move_x(100)
                        p2_posicao_x += 100
                    elif -90 < p2_posicao_x - p1_posicao_x < 0:
                        HP2 -= 10
                        if especial_1 < 100:
                            especial_1 += 5
                        animacao2.move_x(-100)
                        p2_posicao_x -= 100
            elif (teclado.key_pressed("G")) and delay1 == 0:
                status_animacao.setState(Animacao.ESPECIAL)
                status_animacao.setMove_x(dt,Animacao.INICIAL)
                status_animacao.setState_h(Animacao.SUPER)
                duracao_ataque_p1 = 0.4
                if status_animacao2.getState_h() == 1 or status_animacao2.getState_h() == 4 or status_animacao2.getState_h() == 5:
                    if 0 < p2_posicao_x - p1_posicao_x < 90:
                        HP2 -= 40
                        if especial_1 < 100:
                            especial_1 += 5
                        animacao2.move_x(100)
                        p2_posicao_x += 100
                        status_animacao.setState_s(Animacao.SIM)
                    elif -90 < p2_posicao_x - p1_posicao_x < 0:
                        HP2 -= 40
                        if especial_1 < 100:
                            especial_1 += 5
                        animacao2.move_x(-100)
                        p2_posicao_x -= 100
                        status_animacao.setState_s(Animacao.SIM)
            elif (teclado.key_pressed("W")) and delay1_mov == 0:
                status_animacao.setState(Animacao.PULAR)
                status_animacao.setMove_x(dt,Animacao.INICIAL)
                status_animacao.setState_h(Animacao.AR_SUBINDO)
            elif (teclado.key_pressed("S")):
                status_animacao.setState(Animacao.ABAIXAR)
                status_animacao.setMove_x(dt,Animacao.INICIAL)
                status_animacao.setState_h(Animacao.ABAIXANDO)
            elif(teclado.key_pressed("A")):
                if p1_posicao_x > -30:
                    status_animacao.setState(Animacao.ANDAR)
                    status_animacao.setMove_x(dt,Animacao.ESQUERDA)
                    p1_posicao_x = p1_posicao_x - 400*dt
                else:
                    status_animacao.setMove_x(dt,Animacao.INICIAL)
            elif (teclado.key_pressed("D")):
                if p1_posicao_x < 575:
                    status_animacao.setState(Animacao.ANDAR)
                    status_animacao.setMove_x(dt,Animacao.DIREITA)
                    p1_posicao_x = p1_posicao_x + 400*dt
                else:
                    status_animacao.setMove_x(dt,Animacao.INICIAL)
            else:
                status_animacao.setState(Animacao.PARADO)
                status_animacao.setMove_x(dt,Animacao.INICIAL)

            ######## Persongaem 1 esta no ar ############
        elif status_animacao.getState_h() == 2 or status_animacao.getState_h() == 3:
            if(teclado.key_pressed("A")):
                if p1_posicao_x > -30:
                    status_animacao.setMove_x(dt,Animacao.ESQUERDA)
                    p1_posicao_x = p1_posicao_x - 400*dt
                else:
                    status_animacao.setMove_x(dt,Animacao.INICIAL)
            elif (teclado.key_pressed("D")):
                if p1_posicao_x < 575:
                    status_animacao.setMove_x(dt,Animacao.DIREITA)
                    p1_posicao_x = p1_posicao_x + 400*dt
                else:
                    status_animacao.setMove_x(dt,Animacao.INICIAL)
            else:
                status_animacao.setMove_x(dt,Animacao.INICIAL)
            if status_animacao.getState_h() == 2:
                status_animacao.setMove_y(dt,Animacao.CIMA)
                p1_posicao_y = p1_posicao_y - 600*dt
                if p1_posicao_y <20:
                    status_animacao.setState_h(Animacao.AR_DESCENDO)
            elif status_animacao.getState_h() == 3:
                status_animacao.setMove_y(dt,Animacao.BAIXO)
                p1_posicao_y = p1_posicao_y + 600*dt
                if p1_posicao_y >= 250:
                    status_animacao.setMove_y(dt,Animacao.INICIAL)
                    status_animacao.setState_h(Animacao.CHAO)
                    p1_posicao_y = p1_posicao_y - 600*dt
                    delay1_mov = 0.2

        ######## Persongaem 1 esta socando ############
        elif status_animacao.getState_h() == 4:
            duracao_ataque_p1 -= 1*dt
            if duracao_ataque_p1 <= 0:
                delay1 = 1
                status_animacao.setState_h(Animacao.CHAO)
                duracao_ataque_p1 = 0

        ######## Personagem 1 esta chutando ############
        elif status_animacao.getState_h() == 5:
            duracao_ataque_p1 -= 1*dt
            if duracao_ataque_p1 <= 0:
                delay1 = 1
                status_animacao.setState_h(Animacao.CHAO)
                duracao_ataque_p1 = 0

        ######## Personagem 1 esta abaixado ############
        elif status_animacao.getState_h() == 6:
            status_animacao.setState_h(Animacao.CHAO)

        ######## Persongaem 1 esta no especial ############
        elif status_animacao.getState_h() == 7:
            duracao_ataque_p1 -= 1*dt
            status_animacao.setState_s(Animacao.SIM)
            if duracao_ataque_p1 <= 0:
                status_animacao.setState_s(Animacao.NAO)
                velocidade_especial_p1 = 0
                delay1 = 1
                status_animacao.setState_h(Animacao.CHAO)
                duracao_ataque_p1 = 0
                especial_1 = 0

        ############## Sequencias de Sprites do personagem 1 ###########
        if p1_modificacao != status_animacao.getState():
            if status_animacao.getState() == 1:
                animacao.set_sequence(u, u+3, True)
            elif status_animacao.getState() == 2:
                animacao.set_sequence(u+2, u+6, True)
            elif status_animacao.getState() == 3:
                animacao.set_sequence(u+6, u+7, True)
            elif status_animacao.getState() == 4:
                animacao.set_sequence(u+7, u+8, True)
            elif status_animacao.getState() == 5:
                animacao.set_sequence(u+8, u+10, True)
            elif status_animacao.getState() == 6:
                animacao.set_sequence(u+10, u+13, True)
            elif status_animacao.getState() == 7:
                animacao.set_sequence(u+14, u+15, True)

        ######### Personagem 2 esta no chao ###############
        if status_animacao2.getState_h() == 1:
            if (teclado.key_pressed("I")) and delay2 == 0:
                status_animacao2.setState(Animacao.SOCO)
                status_animacao2.setMove_x(dt,Animacao.INICIAL)
                status_animacao2.setState_h(Animacao.SOCANDO)
                duracao_ataque_p2 = 0.2
                if status_animacao.getState_h() == 1 or status_animacao.getState_h() == 4 or status_animacao.getState_h() == 5:
                    if 0 < p2_posicao_x - p1_posicao_x < 90:
                        HP1 -= 5
                        if especial_2 < 100:
                            especial_2 += 5
                        animacao.move_x(-100)
                        p1_posicao_x -= 100
                    elif -90 < p2_posicao_x - p1_posicao_x < 0:
                        HP1 -= 5
                        if especial_2 < 100:
                            especial_2 += 5
                        animacao.move_x(100)
                        p1_posicao_x += 100
            elif (teclado.key_pressed("K")) and delay2 == 0:
                status_animacao2.setState(Animacao.CHUTE)
                status_animacao2.setMove_x(dt,Animacao.INICIAL)
                status_animacao2.setState_h(Animacao.CHUTANDO)
                duracao_ataque_p2 = 0.4
                if status_animacao.getState_h() == 1 or status_animacao.getState_h() == 4 or status_animacao.getState_h() == 5:
                    if 0 < p2_posicao_x - p1_posicao_x < 90:
                        HP1 -= 10
                        if especial_2 < 100:
                            especial_2 += 5
                        animacao.move_x(-100)
                        p1_posicao_x -= 100
                    elif -90 < p2_posicao_x - p1_posicao_x < 0:
                        HP1 -= 10
                        if especial_2 < 100:
                            especial_2 += 5
                        animacao.move_x(100)
                        p1_posicao_x += 100
            elif (teclado.key_pressed("J")) and delay2 == 0:
                status_animacao2.setState(Animacao.ESPECIAL)
                status_animacao2.setMove_x(dt,Animacao.INICIAL)
                status_animacao2.setState_h(Animacao.SUPER)
                duracao_ataque_p2 = 0.4
                if status_animacao.getState_h() == 1 or status_animacao.getState_h() == 4 or status_animacao.getState_h() == 5:
                    if 0 < p2_posicao_x - p1_posicao_x < 90:
                        HP1 -= 40
                        if especial_2 < 100:
                            especial_2 += 5
                        animacao.move_x(100)
                        p1_posicao_x += 100
                        status_animacao2.setState_s(Animacao.SIM)
                    elif -90 < p2_posicao_x - p1_posicao_x < 0:
                        HP1 -= 40
                        if especial_2 < 100:
                            especial_2 += 5
                        animacao.move_x(-100)
                        p1_posicao_x -= 100
                        status_animacao2.setState_s(Animacao.SIM)
            elif (teclado.key_pressed("UP")) and delay2_mov == 0:
                status_animacao2.setState(Animacao.PULAR)
                status_animacao2.setMove_x(dt,Animacao.INICIAL)
                status_animacao2.setState_h(Animacao.AR_SUBINDO)
            elif (teclado.key_pressed("DOWN")):
                status_animacao2.setState(Animacao.ABAIXAR)
                status_animacao2.setMove_x(dt,Animacao.INICIAL)
            elif(teclado.key_pressed("LEFT")):
                if p2_posicao_x > -30:
                    status_animacao2.setState(Animacao.ANDAR)
                    status_animacao2.setMove_x(dt,Animacao.ESQUERDA)
                    p2_posicao_x = p2_posicao_x - 400*dt
                else:
                    status_animacao2.setMove_x(dt,Animacao.INICIAL)
            elif (teclado.key_pressed("RIGHT")):
                if p2_posicao_x < 575:
                    status_animacao2.setState(Animacao.ANDAR)
                    status_animacao2.setMove_x(dt,Animacao.DIREITA)
                    p2_posicao_x = p2_posicao_x + 400*dt
                else:
                    status_animacao2.setMove_x(dt,Animacao.INICIAL)
            else:
                status_animacao2.setState(Animacao.PARADO)
                status_animacao2.setMove_x(dt,Animacao.INICIAL)

            ########## Persongaem 2 esta no ar ###############
        elif status_animacao2.getState_h() == 2 or status_animacao2.getState_h() == 3:
            if(teclado.key_pressed("LEFT")):
                if p2_posicao_x > -30:
                    status_animacao2.setMove_x(dt,Animacao.ESQUERDA)
                    p2_posicao_x = p2_posicao_x - 400*dt
                else:
                    status_animacao2.setMove_x(dt,Animacao.INICIAL)
            elif (teclado.key_pressed("RIGHT")):
                if p2_posicao_x < 575:
                    status_animacao2.setMove_x(dt,Animacao.DIREITA)
                    p2_posicao_x = p2_posicao_x + 400*dt
                else:
                    status_animacao2.setMove_x(dt,Animacao.INICIAL)
            else:
                status_animacao2.setMove_x(dt,Animacao.INICIAL)
            if status_animacao2.getState_h() == 2:
                status_animacao2.setMove_y(dt,Animacao.CIMA)
                p2_posicao_y = p2_posicao_y - 600*dt
                if p2_posicao_y <20:
                    status_animacao2.setState_h(Animacao.AR_DESCENDO)
            elif status_animacao2.getState_h() == 3:
                status_animacao2.setMove_y(dt,Animacao.BAIXO)
                p2_posicao_y = p2_posicao_y + 600*dt
                if p2_posicao_y >= 250:
                    status_animacao2.setMove_y(dt,Animacao.INICIAL)
                    status_animacao2.setState_h(Animacao.CHAO)
                    p2_posicao_y = p2_posicao_y - 600*dt
                    delay2_mov = 0.2

        ######## Persongaem 2 esta socando ############
        elif status_animacao2.getState_h() == 4:
            duracao_ataque_p2 -= 1*dt
            if duracao_ataque_p2 <= 0:
                delay2 = 1
                status_animacao2.setState_h(Animacao.CHAO)
                duracao_ataque_p2 = 0

        ######## Persongaem 2 esta chutando ############
        elif status_animacao2.getState_h() == 5:
            duracao_ataque_p2 -= 1*dt
            if duracao_ataque_p2 <= 0:
                delay2 = 1
                status_animacao2.setState_h(Animacao.CHAO)
                duracao_ataque_p2 = 0

        ######## Persongaem 2 esta no especial ############
        elif status_animacao2.getState_h() == 7:
            duracao_ataque_p2 -= 1*dt
            status_animacao2.setState_s(Animacao.SIM)
            if duracao_ataque_p2 <= 0:
                status_animacao2.setState_s(Animacao.NAO)
                velocidade_especial_p2 = 0
                delay2 = 1
                status_animacao2.setState_h(Animacao.CHAO)
                duracao_ataque_p2 = 0
                especial_2 = 0

        ########## Sequencias de Sprites do personagem 2 ###########
        if p2_modificacao != status_animacao2.getState():
            if status_animacao2.getState() == 1:
                animacao2.set_sequence(i+0, i+3, True)
            elif status_animacao2.getState() == 2:
                animacao2.set_sequence(i+2, i+6, True)
            elif status_animacao2.getState() == 3:
                animacao2.set_sequence(i+6, i+7, True)
            elif status_animacao2.getState() == 4:
                animacao2.set_sequence(i+7, i+8, True)
            elif status_animacao2.getState() == 5:
                animacao2.set_sequence(i+8, i+10, True)
            elif status_animacao2.getState() == 6:
                animacao2.set_sequence(i+10, i+13, True)
            elif status_animacao2.getState() == 7:
                animacao2.set_sequence(i+14, i+15, True)

        ####### Delays ########
        if delay1 > 0:
            delay1 -= dt*1
            if delay1 <= 0:
                delay1 = 0
        if delay2 > 0:
            delay2 -= dt*1
            if delay2 <= 0:
                delay2 = 0

        if delay1_mov > 0:
            delay1_mov -= dt*1
            if delay1_mov <= 0:
                delay1_mov = 0
        if delay2_mov > 0:
            delay2_mov -= dt*1
            if delay2_mov <= 0:
                delay2_mov = 0

        if p1_posicao_x < -35:
            animacao.move_x(5000*dt)
            p1_posicao_x +=5000*dt
        if p1_posicao_x >580:
            animacao.move_x(-5000*dt)
            p1_posicao_x -=5000*dt

        if p2_posicao_x < -35:
            animacao2.move_x(5000*dt)
            p2_posicao_x +=5000*dt
        if p2_posicao_x >580:
            animacao2.move_x(-5000*dt)
            p2_posicao_x -=5000*dt

        tempo +=dt
        if tempo > 4:
            tempo = 0
            if especial_1 < 100:
                especial_1 += 5
            if especial_2 < 100:
                especial_2 += 5


        HP_controle(HP1,HP_p1)
        HP_controle(HP2,HP_p2)
        especial_controle(especial_1,especial_p1)
        especial_controle(especial_2,especial_p2)

        dt = janela.delta_time()
        fundo_jogo.draw()
        animacao.move_x(status_animacao.getMove_x())
        animacao.move_y(status_animacao.getMove_y())
        animacao.draw()
        animacao.update()
        animacao2.move_x(status_animacao2.getMove_x())
        animacao2.move_y(status_animacao2.getMove_y())
        animacao2.draw()
        animacao2.update()
        janela.draw_text(texto_personagem_p1, 20, 10, size=20, color=(230,230,230), font_name="Franklin Gothic Demi Cond", bold=True, italic=True)
        janela.draw_text(texto_personagem_p2, 602, 10, size=20, color=(230,230,230), font_name="Franklin Gothic Demi Cond", bold=True, italic=True)
        janela.draw_text(texto_round, 295, 10, size=40, color=(230,230,230), font_name="Franklin Gothic Demi Cond", bold=True, italic=True)
        HP_p1.draw()
        HP_p2.draw()
        HP_p1.update()
        HP_p2.update()
        especial_p1.draw()
        especial_p2.draw()
        especial_p1.update()
        especial_p2.update()
        if status_animacao.getState_s() == 1:
             velocidade_especial_p1 = especial_usar(status_personagem_p1.getState(),u,velocidade_especial_p1)
        if status_animacao2.getState_s() == 1:
            velocidade_especial_p2 = especial_usar(status_personagem_p2.getState(),i,velocidade_especial_p2)

        if HP1 <= 0 or HP2 <= 0:
            if HP1 <= 0:
                if status_round.getVitoria_p2() == 0:
                    status_round.setVitoria_p2(Round.P2_VITORIA_1)
                elif status_round.getVitoria_p2() == 1:
                    status_round.setVitoria_p2(Round.P2_VITORIA_2)
            if HP2 <= 0:
                if status_round.getVitoria_p1() == 0:
                    status_round.setVitoria_p1(Round.P1_VITORIA_1)
                elif status_round.getVitoria_p1() == 1:
                    status_round.setVitoria_p1(Round.P1_VITORIA_2)

            if status_round.getRound() == 1:
                status_round.setRound(Round.ROUND_2)
                texto_round = "ROUND 2"
            elif status_round.getRound() == 2:
                if status_round.getVitoria_p1() == 2 or status_round.getVitoria_p2() == 2:
                    status.setState(GameState.ESCOLHAS)
                else:
                    status_round.setRound(Round.ROUND_3)
                    texto_round = "ROUND 3"
            elif status_round.getRound() == 3:
                status.setState(GameState.ESCOLHAS)
    janela.update()