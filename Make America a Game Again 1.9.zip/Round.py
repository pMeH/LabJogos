class Round(object):
    ROUND_1 = 1
    ROUND_2 = 2
    ROUND_3 = 3
    P1_VITORIA_0 = 0
    P1_VITORIA_1 = 1
    P1_VITORIA_2 = 2
    P2_VITORIA_0 = 0
    P2_VITORIA_1 = 1
    P2_VITORIA_2 = 2



    def __init__(self,round = ROUND_1,vitoria_p1 = P1_VITORIA_0,vitoria_p2 = P2_VITORIA_0):
        self.round = round
        self.vitoria_p1 = vitoria_p1
        self.vitoria_p2 = vitoria_p2

    def setRound(self, round):
        self.round = round

    def getRound(self):
        return self.round

    def setVitoria_p1(self, vitoria_p1):
        self.vitoria_p1 = vitoria_p1

    def getVitoria_p1(self):
        return self.vitoria_p1

    def setVitoria_p2(self, vitoria_p2):
        self.vitoria_p2 = vitoria_p2

    def getVitoria_p2(self):
        return self.vitoria_p2
