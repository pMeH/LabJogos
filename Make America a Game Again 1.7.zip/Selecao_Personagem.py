class Personagem(object):

    #Personagem
    TRUMP = 1
    MEXICANO = 2
    TERRORISTA = 3
    PUTIN = 4

    #Pronto?
    NAO = 0
    SIM = 1

    def __init__(self,state = TRUMP, pronto = NAO):
        self.state = state
        self.pronto = pronto

    def setState(self, state):
        self.state = state

    def getState(self):
        return self.state

    def setPronto(self, pronto):
        self.pronto = pronto

    def getPronto(self):
        return self.pronto