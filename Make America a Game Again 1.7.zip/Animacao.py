class Animacao(object):

    #Sprites
    PARADO = 1
    ANDAR = 2
    ABAIXAR = 3
    PULAR = 4
    SOCO = 5
    CHUTE = 6
    #Movimentacao_x do personagem
    INICIAL = 0
    DIREITA = INICIAL + 400
    ESQUERDA = INICIAL - 400
    #Movimentacao_y do personagem
    INICIAL = 0
    CIMA = INICIAL - 1000
    BAIXO = INICIAL + 1000
    BAIXO_TESTE = INICIAL + 400
    #Status State_h
    CHAO = 1
    AR_SUBINDO = 2
    AR_DESCENDO = 3

    def __init__(self, state = PARADO, move_x = INICIAL, move_y = INICIAL , state_h = CHAO):
        self.state = state
        self.move_x = move_x
        self.move_y = move_y
        self.state_h = state_h

    #Sprites
    def setState(self, state):
        self.state = state

    def getState(self):
        return self.state

    #Movimentacao_x do personagem
    def setMove_x(self, dt, move_x):
        self.move_x = move_x * dt

    def getMove_x(self):
        return self.move_x

    #Movimentacao_y do personagem
    def setMove_y(self, dt, move_y):
        self.move_y = move_y * dt

    def getMove_y(self):
        return self.move_y

    #Status do personagem (No chao ou no Ar)
    def setState_h(self, state_h):
        self.state_h = state_h

    def getState_h(self):
        return self.state_h