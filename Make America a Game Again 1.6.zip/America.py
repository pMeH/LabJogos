from PPlay.gameimage import *
from PPlay.window import *
from PPlay.sprite import *
from PPlay.sound import *
from GameState import*
from Frame import *
from Selecao_Personagem import *
from Animacao import *

#Geral
janela = Window(700, 400)
janela.set_title("Make America a Game Again")
teclado = Window.get_keyboard()
status=GameState(GameState.START)

# Botao de Start
fundo_start = GameImage("Again.png")
button_start = Sprite("Start.png", 2)
button_start.set_total_duration(1000)
button_start.move_x(108)
button_start.move_y(324)
button_start.set_sequence(0, 2,True)
#som = Sound("Trump_total.ogg")
#som.load("Trump_total.ogg")
#som.set_volume(100)
#som.play()

# Tela inicial
status_escolhas = Frame(Frame.JOGAR)
fundo_escolhas = GameImage("Flag.jpg")
frame_escolhas = GameImage("Frame.png")

# Selecao de persongens
status_personagem_p1 = Personagem(Personagem.TRUMP,Personagem.NAO)
status_personagem_p2 = Personagem(Personagem.PUTIN,Personagem.NAO)
fundo_personagem = GameImage("selecao_personagem_fundo.png")
p1_frame_personagem = GameImage("selecao_frame_p1.png")
p2_frame_personagem = GameImage("selecao_frame_p2.png")
p3_frame_personagem = GameImage("selecao_frame_ambos.png")
 # Sprites p1 do selecao de personagens
p1_animacao_personagem = Sprite("personagens_direita.png",12)
p1_animacao_personagem.move_x(60)
p1_animacao_personagem.move_y(110)
p1_animacao_personagem.set_sequence(0, 3, True)
p1_animacao_personagem.set_total_duration(1600)
 # Sprites p2 da selecao de personagens
p2_animacao_personagem = Sprite("personagens_esquerda.png",12)
p2_animacao_personagem.move_x(500)
p2_animacao_personagem.move_y(105)
p2_animacao_personagem.set_sequence(0, 3, True)
p2_animacao_personagem.set_total_duration(1600)

pronto_personagem_p1 = 0
pronto_personagem_p2 = 0

# Controles
fundo_controles = GameImage("Controles.png")

# Jogo
fundo_jogo = GameImage("background.jpg")
    #Primeiro personagem
#animacao = Sprite("Trump.png",30)
p1_posicao_x = 8
p1_posicao_y = 250
status_animacao = Animacao(Animacao.PARADO, Animacao.INICIAL, Animacao.INICIAL, Animacao.CHAO)
    #Segundo personagem
animacao2 = Sprite("Terrorista.png",30)
p2_posicao_x = 540
p2_posicao_y = 250
status_animacao2 = Animacao(Animacao.PARADO, Animacao.INICIAL, Animacao.INICIAL, Animacao.CHAO)

u = 0
i = 15

dt = janela.delta_time()

def start(teclado):
    fundo_start.draw()
    button_start.draw()
    button_start.update()
    if(teclado.key_pressed("SPACE")):
            status.setState(GameState.ESCOLHAS)

def escolhas(teclado):
    fundo_escolhas.draw()
    frame_escolhas.draw()

    if ((teclado.key_pressed("w")) or (teclado.key_pressed("up"))) and status_escolhas.getState()== 1:
        status_escolhas.setState(Frame.SAIR)
        janela.delay(150)
    elif ((teclado.key_pressed("s")) or (teclado.key_pressed("down"))) and status_escolhas.getState()== 1:
        status_escolhas.setState(Frame.CONTROLES)
        janela.delay(150)
    elif ((teclado.key_pressed("w")) or (teclado.key_pressed("up"))) and status_escolhas.getState()== 2:
        status_escolhas.setState(Frame.JOGAR)
        janela.delay(150)
    elif ((teclado.key_pressed("s")) or (teclado.key_pressed("down"))) and status_escolhas.getState()== 2:
        status_escolhas.setState(Frame.SAIR)
        janela.delay(150)
    elif ((teclado.key_pressed("w")) or (teclado.key_pressed("up"))) and status_escolhas.getState()== 3:
        status_escolhas.setState(Frame.CONTROLES)
        janela.delay(150)
    elif ((teclado.key_pressed("s")) or (teclado.key_pressed("down"))) and status_escolhas.getState()== 3:
        status_escolhas.setState(Frame.JOGAR)
        janela.delay(150)

    if status_escolhas.getState() == 1:
        frame_escolhas.set_position(256,125)
        if teclado.key_pressed("ENTER"):
            status.setState(GameState.PERSONAGEM)
            janela.delay(150)
    elif status_escolhas.getState() == 2:
        frame_escolhas.set_position(256,201)
        if teclado.key_pressed("ENTER"):
            status.setState(GameState.CONTROLES)
    elif status_escolhas.getState() == 3:
        frame_escolhas.set_position(256,282)
        if teclado.key_pressed("ENTER"):
            janela.close()

def personagem(teclado):

    status_personagem_iguais = 0
    modificacao_personagem_p1 = status_personagem_p1.getState()
    modificacao_personagem_p2 = status_personagem_p2.getState()

    if status_personagem_p1.getPronto() == 0:
        ########## Frame para o player 1 #############
        if(teclado.key_pressed("d")) and status_personagem_p1.getState()== 1:
            status_personagem_p1.setState(Personagem.MEXICANO)
            janela.delay(200)
        elif(teclado.key_pressed("d")) and status_personagem_p1.getState()== 2:
            status_personagem_p1.setState(Personagem.TERRORISTA)
            janela.delay(200)
        elif(teclado.key_pressed("d")) and status_personagem_p1.getState()== 3:
            status_personagem_p1.setState(Personagem.PUTIN)
            janela.delay(200)
        elif(teclado.key_pressed("d")) and status_personagem_p1.getState()== 4:
            status_personagem_p1.setState(Personagem.TRUMP)
            janela.delay(200)
        elif(teclado.key_pressed("a")) and status_personagem_p1.getState()== 1:
            status_personagem_p1.setState(Personagem.PUTIN)
            janela.delay(200)
        elif(teclado.key_pressed("a")) and status_personagem_p1.getState()== 2:
            status_personagem_p1.setState(Personagem.TRUMP)
            janela.delay(200)
        elif(teclado.key_pressed("a")) and status_personagem_p1.getState()== 3:
            status_personagem_p1.setState(Personagem.MEXICANO)
            janela.delay(200)
        elif(teclado.key_pressed("a")) and status_personagem_p1.getState()== 4:
            status_personagem_p1.setState(Personagem.TERRORISTA)
            janela.delay(200)

    if status_personagem_p2.getPronto() == 0:
        ########## Frame para o player 2 ##############
        if(teclado.key_pressed("right")) and status_personagem_p2.getState()== 1:
            status_personagem_p2.setState(Personagem.MEXICANO)
            janela.delay(200)
        elif(teclado.key_pressed("right")) and status_personagem_p2.getState()== 2:
            status_personagem_p2.setState(Personagem.TERRORISTA)
            janela.delay(200)
        elif(teclado.key_pressed("right")) and status_personagem_p2.getState()== 3:
            status_personagem_p2.setState(Personagem.PUTIN)
            janela.delay(200)
        elif(teclado.key_pressed("right")) and status_personagem_p2.getState()== 4:
            status_personagem_p2.setState(Personagem.TRUMP)
            janela.delay(200)
        elif(teclado.key_pressed("left")) and status_personagem_p2.getState()== 1:
            status_personagem_p2.setState(Personagem.PUTIN)
            janela.delay(200)
        elif(teclado.key_pressed("left")) and status_personagem_p2.getState()== 2:
            status_personagem_p2.setState(Personagem.TRUMP)
            janela.delay(200)
        elif(teclado.key_pressed("left")) and status_personagem_p2.getState()== 3:
            status_personagem_p2.setState(Personagem.MEXICANO)
            janela.delay(200)
        elif(teclado.key_pressed("left")) and status_personagem_p2.getState()== 4:
            status_personagem_p2.setState(Personagem.TERRORISTA)
            janela.delay(200)

    ################## Para o plyer 1 #####################
    if status_personagem_p1.getState() == 1:
        if status_personagem_p1.getState() == status_personagem_p2.getState():
            p3_frame_personagem.set_position(91,301)
            status_personagem_iguais = 1
        p1_frame_personagem.set_position(91,301)
        if teclado.key_pressed("e"):
            status_personagem_p1.setPronto(Personagem.SIM)
    elif status_personagem_p1.getState() == 2:
        if status_personagem_p1.getState() == status_personagem_p2.getState():
            p3_frame_personagem.set_position(217,301)
            status_personagem_iguais = 1
        p1_frame_personagem.set_position(217,301)
        if teclado.key_pressed("e"):
            status_personagem_p1.setPronto(Personagem.SIM)
    elif status_personagem_p1.getState() == 3:
        if status_personagem_p1.getState() == status_personagem_p2.getState():
            p3_frame_personagem.set_position(346,301)
            status_personagem_iguais = 1
        p1_frame_personagem.set_position(346,301)
        if teclado.key_pressed("e"):
            status_personagem_p1.setPronto(Personagem.SIM)
    elif status_personagem_p1.getState() == 4:
        if status_personagem_p1.getState() == status_personagem_p2.getState():
            p3_frame_personagem.set_position(475,301)
            status_personagem_iguais = 1
        p1_frame_personagem.set_position(475,301)
        if teclado.key_pressed("e"):
            status_personagem_p1.setPronto(Personagem.SIM)

    ################## Para o plyer 2 #####################
    if status_personagem_p2.getState() == 1:
        p2_frame_personagem.set_position(91,301)
        if teclado.key_pressed("i"):
            status_personagem_p2.setPronto(Personagem.SIM)
    elif status_personagem_p2.getState() == 2:
        p2_frame_personagem.set_position(217,301)
        if teclado.key_pressed("i"):
            status_personagem_p2.setPronto(Personagem.SIM)
    elif status_personagem_p2.getState() == 3:
        p2_frame_personagem.set_position(346,301)
        if teclado.key_pressed("i"):
            status_personagem_p2.setPronto(Personagem.SIM)
    elif status_personagem_p2.getState() == 4:
        p2_frame_personagem.set_position(475,301)
        if teclado.key_pressed("i"):
            status_personagem_p2.setPronto(Personagem.SIM)

    ################ Sprites p1 #######################

    if modificacao_personagem_p1 != status_personagem_p1.getState():
        if status_personagem_p1.getState() == 1:
            p1_animacao_personagem.set_sequence(0, 3, True)
        elif status_personagem_p1.getState() == 2:
            p1_animacao_personagem.set_sequence(3, 6, True)
        elif status_personagem_p1.getState() == 3:
            p1_animacao_personagem.set_sequence(6, 9, True)
        elif status_personagem_p1.getState() == 4:
            p1_animacao_personagem.set_sequence(9, 12, True)

    ################ Sprites p2 ############################

    if modificacao_personagem_p2 != status_personagem_p2.getState():
        if status_personagem_p2.getState() == 1:
            p2_animacao_personagem.set_sequence(0, 3, True)
        elif status_personagem_p2.getState() == 2:
            p2_animacao_personagem.set_sequence(3, 6, True)
        elif status_personagem_p2.getState() == 3:
            p2_animacao_personagem.set_sequence(6, 9, True)
        elif status_personagem_p2.getState() == 4:
            p2_animacao_personagem.set_sequence(9, 12, True)

    ############ Lugar que o frame eh enviado quando nao foi utilizado ################
    if status_personagem_iguais == 0:
        p3_frame_personagem.set_position(-100,-100)

    fundo_personagem.draw()

    p1_frame_personagem.draw()
    p2_frame_personagem.draw()
    p3_frame_personagem.draw()

    p1_animacao_personagem.draw()
    p1_animacao_personagem.update()
    p2_animacao_personagem.draw()
    p2_animacao_personagem.update()

    if status_personagem_p1.getPronto() == 1 and status_personagem_p2.getPronto() == 1:
        status.setState(GameState.JOGO)

def controles(teclado):
    fundo_controles.draw()
    if teclado.key_pressed("ENTER"):
        status.setState(GameState.ESCOLHAS)

while True:
    if status.getState() == GameState.START:
        start(teclado)
    elif status.getState() == GameState.ESCOLHAS:
        escolhas(teclado)
    elif status.getState() == GameState.PERSONAGEM:
        personagem(teclado)
    elif status.getState() == GameState.CONTROLES:
        controles(teclado)
    elif status.getState() == GameState.JOGO:

        ######## Seleciona o Personagem escolhido ##########
        if status_personagem_p1.getPronto() == 1 and status_personagem_p2.getPronto() == 1:
            if status_personagem_p1.getState() == 1:
                animacao = Sprite("Trump.png",30)
            elif status_personagem_p1.getState() == 2:
                animacao = Sprite("Mexicano.png",30)
            elif status_personagem_p1.getState() == 3:
                animacao = Sprite("Terrorista.png",30)
            elif status_personagem_p1.getState() == 4:
                animacao = Sprite("Terrorista.png",30)

            if status_personagem_p2.getState() == 1:
                animacao2 = Sprite("Trump.png",30)
            elif status_personagem_p2.getState() == 2:
                animacao2 = Sprite("Mexicano.png",30)
            elif status_personagem_p2.getState() == 3:
                animacao2 = Sprite("Terrorista.png",30)
            elif status_personagem_p2.getState() == 4:
                animacao2 = Sprite("Terrorista.png",30)

            animacao.move_x(p1_posicao_x)
            animacao.move_y(p1_posicao_y)
            animacao.set_sequence(0, 3, True)
            animacao.set_total_duration(4000)

            animacao2.move_x(p2_posicao_x)
            animacao2.move_y(p2_posicao_y)
            animacao2.set_sequence(15, 18, True)
            animacao2.set_total_duration(4000)

            status_personagem_p1.setPronto(Personagem.NAO)
            status_personagem_p2.setPronto(Personagem.NAO)

        # Variaveis criadas com o proposito de que os sprites serao trocados apenas quando o proximo
        # for diferente do anterior para que nao fique voltando para o comeco o tempo t_odo.
        p1_modificacao = status_animacao.getState()
        p2_modificacao = status_animacao2.getState()

        ######## Mudanca de Sprite (direita pra esquerda) #########
        if p2_posicao_x > p1_posicao_x:
            u = 0
            i = 15
        if p2_posicao_x < p1_posicao_x:
            u = 15
            i = 0

        ######### Personagem 1 no chao   #############
        if status_animacao.getState_h() == 1:
            if (teclado.key_pressed("E")):
                status_animacao.setState(Animacao.SOCO)
                status_animacao.setMove_x(dt,Animacao.INICIAL)
            elif (teclado.key_pressed("F")):
                status_animacao.setState(Animacao.CHUTE)
                status_animacao.setMove_x(dt,Animacao.INICIAL)
            elif (teclado.key_pressed("W")):
                status_animacao.setState(Animacao.PULAR)
                status_animacao.setMove_x(dt,Animacao.INICIAL)
                status_animacao.setState_h(Animacao.AR_SUBINDO)
                p1_subindo = 0
            elif (teclado.key_pressed("S")):
                status_animacao.setState(Animacao.ABAIXAR)
                status_animacao.setMove_x(dt,Animacao.INICIAL)
            elif(teclado.key_pressed("A")):
                if p1_posicao_x > -30:
                    status_animacao.setState(Animacao.ANDAR)
                    status_animacao.setMove_x(dt,Animacao.ESQUERDA)
                    p1_posicao_x = p1_posicao_x - 400*dt
                else:
                    status_animacao.setMove_x(dt,Animacao.INICIAL)
            elif (teclado.key_pressed("D")):
                if p1_posicao_x < 575:
                    status_animacao.setState(Animacao.ANDAR)
                    status_animacao.setMove_x(dt,Animacao.DIREITA)
                    p1_posicao_x = p1_posicao_x + 400*dt
                else:
                    status_animacao.setMove_x(dt,Animacao.INICIAL)
            else:
                status_animacao.setState(Animacao.PARADO)
                status_animacao.setMove_x(dt,Animacao.INICIAL)

            ######## Persongaem 1 esta no ar ############
        elif status_animacao.getState_h() == 2 or status_animacao.getState_h() == 3:
            if(teclado.key_pressed("A")):
                if p1_posicao_x > -30:
                    status_animacao.setMove_x(dt,Animacao.ESQUERDA)
                    p1_posicao_x = p1_posicao_x - 400*dt
                else:
                    status_animacao.setMove_x(dt,Animacao.INICIAL)
            elif (teclado.key_pressed("D")):
                if p1_posicao_x < 575:
                    status_animacao.setMove_x(dt,Animacao.DIREITA)
                    p1_posicao_x = p1_posicao_x + 400*dt
                else:
                    status_animacao.setMove_x(dt,Animacao.INICIAL)
            else:
                status_animacao.setMove_x(dt,Animacao.INICIAL)
            if status_animacao.getState_h() == 2:
                status_animacao.setMove_y(dt,Animacao.CIMA)
                p1_posicao_y = p1_posicao_y - 1000*dt
                if p1_posicao_y <100:
                    status_animacao.setState_h(Animacao.AR_DESCENDO)
            elif status_animacao.getState_h() == 3:
                status_animacao.setMove_y(dt,Animacao.BAIXO)
                p1_posicao_y = p1_posicao_y + 1000*dt
                if p1_posicao_y >= 250:
                    status_animacao.setMove_y(dt,Animacao.INICIAL)
                    status_animacao.setState_h(Animacao.CHAO)
                    p1_posicao_y = p1_posicao_y - 1000*dt

        ############## Sequencias de Sprites do personagem 1 ###########
        if p1_modificacao != status_animacao.getState():
            if status_animacao.getState() == 1:
                animacao.set_sequence(u, u+3, True)
            elif status_animacao.getState() == 2:
                animacao.set_sequence(u+2, u+6, True)
            elif status_animacao.getState() == 3:
                animacao.set_sequence(u+6, u+7, True)
            elif status_animacao.getState() == 4:
                animacao.set_sequence(u+7, u+8, True)
            elif status_animacao.getState() == 5:
                animacao.set_sequence(u+9, u+10, True)
            elif status_animacao.getState() == 6:
                animacao.set_sequence(u+10, u+13, True)

        ######### Personagem 2 esta no chao ###############
        if status_animacao2.getState_h() == 1:
            if (teclado.key_pressed("I")):
                status_animacao2.setState(Animacao.SOCO)
                status_animacao2.setMove_x(dt,Animacao.INICIAL)
            elif (teclado.key_pressed("K")):
                status_animacao2.setState(Animacao.CHUTE)
                status_animacao2.setMove_x(dt,Animacao.INICIAL)
            elif (teclado.key_pressed("UP")):
                status_animacao2.setState(Animacao.PULAR)
                status_animacao2.setMove_x(dt,Animacao.INICIAL)
                status_animacao2.setState_h(Animacao.AR_SUBINDO)
                p2_subindo = 0
            elif (teclado.key_pressed("DOWN")):
                status_animacao2.setState(Animacao.ABAIXAR)
                status_animacao2.setMove_x(dt,Animacao.INICIAL)
            elif(teclado.key_pressed("LEFT")):
                if p2_posicao_x > -30:
                    status_animacao2.setState(Animacao.ANDAR)
                    status_animacao2.setMove_x(dt,Animacao.ESQUERDA)
                    p2_posicao_x = p2_posicao_x - 400*dt
                else:
                    status_animacao2.setMove_x(dt,Animacao.INICIAL)
            elif (teclado.key_pressed("RIGHT")):
                if p2_posicao_x < 575:
                    status_animacao2.setState(Animacao.ANDAR)
                    status_animacao2.setMove_x(dt,Animacao.DIREITA)
                    p2_posicao_x = p2_posicao_x + 400*dt
                else:
                    status_animacao2.setMove_x(dt,Animacao.INICIAL)
            else:
                status_animacao2.setState(Animacao.PARADO)
                status_animacao2.setMove_x(dt,Animacao.INICIAL)

            ########## Persongaem 2 esta no ar ###############
        elif status_animacao2.getState_h() == 2 or status_animacao2.getState_h() == 3:
            if(teclado.key_pressed("LEFT")):
                if p2_posicao_x > -30:
                    status_animacao2.setMove_x(dt,Animacao.ESQUERDA)
                    p2_posicao_x = p2_posicao_x - 400*dt
                else:
                    status_animacao2.setMove_x(dt,Animacao.INICIAL)
            elif (teclado.key_pressed("RIGHT")):
                if p2_posicao_x < 575:
                    status_animacao2.setMove_x(dt,Animacao.DIREITA)
                    p2_posicao_x = p2_posicao_x + 400*dt
                else:
                    status_animacao2.setMove_x(dt,Animacao.INICIAL)
            else:
                status_animacao2.setMove_x(dt,Animacao.INICIAL)
            if status_animacao2.getState_h() == 2:
                status_animacao2.setMove_y(dt,Animacao.CIMA)
                p2_posicao_y = p2_posicao_y - 1000*dt
                if p2_posicao_y <100:
                    status_animacao2.setState_h(Animacao.AR_DESCENDO)
            elif status_animacao2.getState_h() == 3:
                status_animacao2.setMove_y(dt,Animacao.BAIXO)
                p2_posicao_y = p2_posicao_y + 1000*dt
                if p2_posicao_y > 249.6:
                    status_animacao2.setMove_y(dt,Animacao.INICIAL)
                    status_animacao2.setState_h(Animacao.CHAO)
                    p2_posicao_y = p2_posicao_y - 1000*dt

        ########## Sequencias de Sprites do personagem 2 ###########
        if p2_modificacao != status_animacao2.getState():
            if status_animacao2.getState() == 1:
                animacao2.set_sequence(i+0, i+3, True)
            elif status_animacao2.getState() == 2:
                animacao2.set_sequence(i+2, i+6, True)
            elif status_animacao2.getState() == 3:
                animacao2.set_sequence(i+6, i+7, True)
            elif status_animacao2.getState() == 4:
                animacao2.set_sequence(i+7, i+8, True)
            elif status_animacao2.getState() == 5:
                animacao2.set_sequence(i+9, i+10, True)
            elif status_animacao2.getState() == 6:
                animacao2.set_sequence(i+10, i+13, True)

        dt = janela.delta_time()
        fundo_jogo.draw()
        animacao.move_x(status_animacao.getMove_x())
        animacao.move_y(status_animacao.getMove_y())
        animacao.draw()
        animacao.update()
        animacao2.move_x(status_animacao2.getMove_x())
        animacao2.move_y(status_animacao2.getMove_y())
        animacao2.draw()
        animacao2.update()
    janela.update()
