# Trump fala "You Fired" quando terrorista pega fogo
# Delta Time - consertar
# tempo de ataque
# balanceamento do jogo
# personganes diferentes
# modo HISTORIA
# Extra - Trump America (deixa pro bruno)